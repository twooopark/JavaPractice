package com.javaex.exam.fin.java.q01;

public class Q01Test {

	public static void main(String[] args) {
		//	Begin: 이 곳의 코드는 수정하지 않습니다.
		Question01 q1 = new Question01();
		q1.printAnswer(10);
		q1.printAnswer(20);
		//	End: 이 곳의 코드는 수정하지 않습니다.
	}
}
